package abcsupply.stepDefinitions;

import abcsupply.pages.StartNewOrderPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import utilities.Configuration;
import utilities.Driver;

public class StartNewOrderStepDef {


    WebDriver driver = Driver.getDriver();
    StartNewOrderPage startNewOrderPage = new StartNewOrderPage();

//    StartNewOrderPage startNewOrderPage = new StartNewOrderPage();
      String expectedAccountAdminTitle = Titles.signInTitle();
      String accountAdminTitle;
      String starNewOrderTitle;
      String expectedStartNewOrderTitle = Titles.placeNewOrderPageTitle;


    @Given("^user is on account administration page$")
    public void user_is_on_account_administration_page() throws Throwable {
        driver.get(Configuration.getProperty("loginurl"));

//        accountAdminTitle = driver.getTitle();
//        Assert.assertEquals(expectedAccountAdminTitle, accountAdminTitle);

    }

    @When("^user clicks on start new order box$")
    public void user_clicks_on_start_new_order_box() throws Throwable {
        StartNewOrderPage.productSearchBox.click();

    }

    @Then("^user is on New Order - ABC Supply page$")
    public void user_is_on_page() throws Throwable {
        starNewOrderTitle = driver.getTitle();
        Assert.assertEquals(expectedStartNewOrderTitle,starNewOrderTitle);
        System.out.println("this title passed from feature file " + expectedStartNewOrderTitle);

   // StartNewOrderPage.orderTotalPrice

    }
}
