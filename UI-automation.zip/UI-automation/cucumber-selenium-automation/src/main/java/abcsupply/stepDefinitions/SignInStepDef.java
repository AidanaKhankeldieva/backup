package abcsupply.stepDefinitions;

import abcsupply.pages.SignInPage;
import abcsupply.pages.AbcSupplyDashboardPage;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import utilities.Configuration;
import utilities.Driver;

public class SignInStepDef {
    WebDriver driver = Driver.getDriver();

    SignInPage signInPage = new SignInPage();

    AbcSupplyDashboardPage accountAdministrationPage = new AbcSupplyDashboardPage();

     String accountAdminText;
     String expectedAccountAdminText;
     String signInTitle;
     String expectedSignInTitle;

    @Given("^abcsupply login page$")
    public void abcsupply_login_page() throws Throwable {
        driver.get(Configuration.getProperty("loginurl"));
        signInTitle = driver.getTitle();
        expectedSignInTitle = "Sign In to Your Account - ABC Supply";
        Assert.assertEquals(expectedSignInTitle, signInTitle);

    }

    @When("^user log ins with valid username and password$")
    public void user_log_ins_with_valid_username_and_password() throws Throwable {
        signInPage.username.sendKeys(Configuration.getProperty("abcusername"));
        Thread.sleep(2000);
        signInPage.password.sendKeys(Configuration.getProperty("abcpassword"));
        Thread.sleep(2000);

    }

    @And("^clicks on sign in button$")
    public void clicks_on_sing_in_button() throws Throwable {
        signInPage.signInButton.click();

    }

    @Then("^user is on to Account Administration page$")
    public void user_is_on_to_Account_Administration_page() throws Throwable {
        Thread.sleep(2000);
//     accountAdminText = accountAdministrationPage.accountAdminPage.getText();
     expectedAccountAdminText="Account Administration";
        Assert.assertEquals(expectedAccountAdminText,accountAdminText);
        System.out.println("This is the text from account administration page:" + accountAdminText);

    }
}
