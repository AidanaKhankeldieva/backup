package abcsupply.stepDefinitions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Test {
    @Given("^feature file$")
    public void feature_file() throws Throwable {

    }

    @When("^I execute the feature file$")
    public void i_execute_the_feature_file() throws Throwable {

    }

    @Then("^I am able to run the runner class$")
    public void i_am_able_to_run_the_runner_class() throws Throwable {

    }
}
