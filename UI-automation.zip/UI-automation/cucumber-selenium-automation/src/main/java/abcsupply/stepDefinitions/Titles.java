package abcsupply.stepDefinitions;

public class Titles {
      static String signInPageTitle;
      static String accountAdminPageTitle;
      static String placeNewOrderPageTitle;


    public static String signInTitle(){
        signInPageTitle = "Sign In to Your Account - ABC Supply";
        return signInPageTitle;
    }

    public static String accountAdmin(){
        accountAdminPageTitle = "ABC Supply";
        return accountAdminPageTitle;
    }

    public static String placeNewOrder(){
        placeNewOrderPageTitle = "New Order - ABC Supply";
        return placeNewOrderPageTitle;
    }
}
