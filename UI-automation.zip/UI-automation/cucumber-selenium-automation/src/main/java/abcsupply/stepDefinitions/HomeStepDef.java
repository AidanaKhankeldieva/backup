package abcsupply.stepDefinitions;

import abcsupply.pages.HomePage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.WebDriver;
import utilities.Configuration;
import utilities.Driver;

public class HomeStepDef {

    WebDriver driver = Driver.getDriver();
    HomePage homePage = new HomePage();

    @Given("^abcsupply main page$")
    public void abcsupply_main_page() throws Throwable {
        driver.get(Configuration.getProperty("loginurl"));

    }

    @When("^user clicks on sign in feature$")
    public void user_clicks_on_sign_in_feature() throws Throwable {
        homePage.singInLogo.click();

    }

    @Then("^user is on log in page$")
    public void user_is_on_log_in_page() throws Throwable {

    }

}
