package abcsupply.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utilities.Driver;

public class StartNewOrderPage {

    WebDriver driver;

    public StartNewOrderPage(){
        this.driver =  Driver.getDriver();
        PageFactory.initElements(driver, this);
    }

    /**
     * features:
     * add products, delivery Details, review and submit,
     * job account number, ordering from,search branch box, continue
     * job name, product search,
     * product name,product number,product content,quantity,price,extended price,est total price
     */
    @FindBy (id ="orderDraftName")
    public static WebElement orderDraftNameBox;

    @FindBy(id = "search")
    public static WebElement productSearchBox;

    @FindBy (xpath = "//ul[@class='product-search__list']")
    public static WebElement productSearchList;

    @FindBy (xpath = "//span[@class='order-products__name']")
    public static WebElement orderProductName;

    @FindBy (xpath = "//span[@class='order-products__item-number']")
    public static WebElement orderProductNumber;

 //   @FindBy ()

    @FindBy (xpath = "//span[@class='order__total-price']")
    public static WebElement orderTotalPrice;

}
