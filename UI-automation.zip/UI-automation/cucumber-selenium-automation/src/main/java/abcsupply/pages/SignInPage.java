package abcsupply.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utilities.Driver;

public class SignInPage {

    WebDriver driver;
    public SignInPage(){
        this.driver = Driver.getDriver();

        PageFactory.initElements(driver,this);
    }

    /**
     * email address, password, sign in
     * forgot password,not registered yet,back to abcsupply.com
     */
    @FindBy(id = "txtEmail")
    public WebElement username;

    @FindBy(id = "txtPassword")
    public WebElement password;

    @FindBy(id = "btnSignIn")
    public WebElement signInButton;

   // <--action -->

   // username.








}
