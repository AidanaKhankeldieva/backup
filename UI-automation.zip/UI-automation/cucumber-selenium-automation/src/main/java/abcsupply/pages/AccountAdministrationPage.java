package abcsupply.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AccountAdministrationPage {





    //routes to dashboard
    @FindBy (id ="lnkHome")
    WebElement abcDashboard;
}
