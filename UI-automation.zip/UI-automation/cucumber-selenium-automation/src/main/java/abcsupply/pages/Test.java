package abcsupply.pages;

import utilities.Driver;

public class Test extends Driver {


}
