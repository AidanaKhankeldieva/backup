package abcsupply.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utilities.Driver;

import java.util.List;

public class AbcSupplyDashboardPage {

    WebDriver driver;

    public AbcSupplyDashboardPage() {
        this.driver = Driver.getDriver();
        PageFactory.initElements(driver, this);
    }

    /**
     * 1 recent orders,PO#,name, order type, order date, status,status option, order again
     * 2 orders,deliveries, invoices, start new order, account managing
     * 3 upcoming deliveries, all deliveries(same as Deliveries feature),all orders (same as Orders feature)
     * 4 manage users, account settings, admin, account admin,sign out
     */

//        @FindBy(xpath = "//h2[contains(text(), 'Account Administration')]")
//        public WebElement accountAdminPage;
    @FindBy(className = "widget__title")
    public WebElement recentOrderTxt;

    @FindBy (className = "orders__po-number")
    public WebElement poNumber;

    @FindBy (className = "orders__job-name")
    public WebElement jobName;

    @FindBy (className = "orders__type")
    public WebElement orderType;

    @FindBy (className = "orders__date-draft")
    public WebElement orderDate;

    @FindBy (className = "orders__status")
    public WebElement orderStatus;

    @FindBy (id ="widgetOrderStatusInfoButton")
    public WebElement statusTypeButton;

    @FindBy (xpath = "//ul[@class='order-status-list']")
    private List<WebElement> statusOptionList;






    //2
    @FindBy(id = "navOrders")
    WebElement orders;

    @FindBy(id = "navDeliveries")
    public WebElement deliveries;

    @FindBy (id ="navInvoices")
    public WebElement invoices;

    @FindBy(id = "navStartOrder")
    public WebElement startNewOrder;

    @FindBy (id ="navAccount")
    public WebElement accountManage;

    @FindBy (id = "userName")
    public WebElement displayedUsername;

    @FindBy (xpath = "//div[@class='main-nav__links'] //span[2] //span[1]")
    public WebElement getUsersName;


}
