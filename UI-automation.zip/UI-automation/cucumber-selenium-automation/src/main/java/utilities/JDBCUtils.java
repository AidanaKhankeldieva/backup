package utilities;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class JDBCUtils {
    private static Connection connection;
    private static Statement statement;
    private static ResultSet resultSet;


    /**
     * Connecting Java to our sql server
     * @throws SQLException
     */

    public static void establishConnection() throws SQLException {
        connection = DriverManager.getConnection(Configuration.getProperty("dbURL"),
                Configuration.getProperty("dbUserName"),
                Configuration.getProperty("dbPassword"));

    }

    /**
     * run query
     * This method will send query in data base and store data from there in list of maps
     * @param query
     * @return
     */
    public static List<Map<String,Object>> runSQLQuery(String query) throws SQLException{
        //what kind of data type we want to get
        statement = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);

        //after running query we store output in resultSet
        resultSet = statement.executeQuery(query);

        ResultSetMetaData resultSetMetaData = resultSet.getMetaData();

        int columnCount = resultSetMetaData.getColumnCount();// -->stores column size

        List<Map<String,Object>> dbData = new ArrayList<>();

        //next -->goes to next row in a table
        //this loop gets and store only one row
        while (resultSet.next()){
            Map<String, Object> rowMap = new HashMap<>();

            for (int i =1; i<= columnCount; i++){
                rowMap.put(resultSetMetaData.getColumnName(i),
                        resultSet.getObject(resultSetMetaData.getColumnName(i)));

            }
            //once we get the data from row,we have to store in list of maps
            dbData.add(rowMap);
        }
        return dbData;
    }

    public static void closeConnection() throws SQLException {
        if (connection!=null){
            connection.close();
        }

        if (statement!=null){
            statement.close();
        }

        if(resultSet!=null){
            resultSet.close();

        }
    }

    public static int rowCount (String query) throws SQLException{
        statement = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                ResultSet.CONCUR_READ_ONLY);

        resultSet = statement.executeQuery(query);

        ResultSet resultSet1 = resultSet;

        resultSet1.last();

        int numberOfRows = resultSet1.getRow();
        return numberOfRows;
    }




}
